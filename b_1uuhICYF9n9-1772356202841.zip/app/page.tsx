import { AppHeader } from "@/components/app-header"
import { LeftSidebar } from "@/components/left-sidebar"
import { CodeDiffViewer } from "@/components/code-diff-viewer"
import { RightPanel } from "@/components/right-panel"

export default function Home() {
  return (
    <div className="flex h-dvh flex-col bg-background">
      <AppHeader />
      <div className="flex flex-1 overflow-hidden">
        <LeftSidebar />
        <main className="flex flex-1 flex-col overflow-hidden p-3">
          <CodeDiffViewer />
        </main>
        <RightPanel />
      </div>
    </div>
  )
}
