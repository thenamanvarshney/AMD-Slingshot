"use client"

import { useState, useEffect } from "react"
import {
  Sparkles,
  ShieldAlert,
  GraduationCap,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  CheckCircle2,
  Zap,
  ArrowRight,
  Brain,
  Lock,
} from "lucide-react"
import { cn } from "@/lib/utils"

function AnimatedText({
  text,
  delay = 0,
}: {
  text: string
  delay?: number
}) {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), delay)
    return () => clearTimeout(timer)
  }, [delay])

  return (
    <span
      className={cn(
        "transition-all duration-500",
        visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-1"
      )}
    >
      {text}
    </span>
  )
}

function GlassCard({
  children,
  className,
}: {
  children: React.ReactNode
  className?: string
}) {
  return (
    <div
      className={cn(
        "rounded-xl border border-glass-border bg-glass backdrop-blur-xl",
        "transition-all duration-300 hover:border-border/50",
        className
      )}
    >
      {children}
    </div>
  )
}

function AIDiffSummary() {
  const [collapsed, setCollapsed] = useState(false)

  const summaryItems = [
    {
      text: "Replaced plain-text password with bcrypt hash comparison",
      icon: <Lock className="size-3.5 text-primary" />,
      delay: 100,
    },
    {
      text: "Refactored user lookup from O(n\u00B2) nested loop to O(1) HashMap",
      icon: <Zap className="size-3.5 text-primary" />,
      delay: 250,
    },
    {
      text: "Added comprehensive password validation with regex rules",
      icon: <CheckCircle2 className="size-3.5 text-success" />,
      delay: 400,
    },
    {
      text: "Wrapped login handler in useCallback for memoization",
      icon: <Brain className="size-3.5 text-primary" />,
      delay: 550,
    },
    {
      text: "Made login function async for proper bcrypt comparison",
      icon: <ArrowRight className="size-3.5 text-muted-foreground" />,
      delay: 700,
    },
  ]

  return (
    <GlassCard>
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="flex w-full items-center justify-between p-4"
      >
        <div className="flex items-center gap-2.5">
          <div className="flex size-7 items-center justify-center rounded-lg bg-primary/15 shadow-[0_0_12px] shadow-glow-muted">
            <Sparkles className="size-4 text-primary" />
          </div>
          <div className="text-left">
            <h3 className="text-sm font-semibold text-foreground">
              AI Diff Summary
            </h3>
            <p className="text-[10px] text-muted-foreground">
              5 changes detected
            </p>
          </div>
        </div>
        {collapsed ? (
          <ChevronDown className="size-4 text-muted-foreground" />
        ) : (
          <ChevronUp className="size-4 text-muted-foreground" />
        )}
      </button>
      {!collapsed && (
        <div className="flex flex-col gap-2 border-t border-border/30 px-4 pb-4 pt-3">
          {summaryItems.map((item, i) => (
            <div key={i} className="flex items-start gap-2.5">
              <span className="mt-0.5 shrink-0">{item.icon}</span>
              <span className="text-xs leading-relaxed text-secondary-foreground">
                <AnimatedText text={item.text} delay={item.delay} />
              </span>
            </div>
          ))}
        </div>
      )}
    </GlassCard>
  )
}

function SecurityScan() {
  const [collapsed, setCollapsed] = useState(false)

  const issues = [
    {
      severity: "critical" as const,
      title: "Plain-text password comparison removed",
      description:
        "The previous code compared passwords directly. The new code uses bcrypt's compare() function - a secure, constant-time comparison.",
      status: "resolved" as const,
    },
    {
      severity: "warning" as const,
      title: "Password validation could be stronger",
      description:
        "Consider adding special character requirements and checking against common password lists for enterprise-grade security.",
      status: "active" as const,
    },
    {
      severity: "info" as const,
      title: "Consider rate limiting login attempts",
      description:
        "While bcrypt adds computational cost, adding explicit rate limiting provides defense-in-depth against brute force attacks.",
      status: "active" as const,
    },
  ]

  return (
    <GlassCard>
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="flex w-full items-center justify-between p-4"
      >
        <div className="flex items-center gap-2.5">
          <div className="flex size-7 items-center justify-center rounded-lg bg-warning/15 shadow-[0_0_12px] shadow-warning/10">
            <ShieldAlert className="size-4 text-warning" />
          </div>
          <div className="text-left">
            <h3 className="text-sm font-semibold text-foreground">
              Security Scan
            </h3>
            <p className="text-[10px] text-muted-foreground">
              1 resolved, 2 advisories
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex size-5 items-center justify-center rounded-full bg-success/15 text-[9px] font-bold text-success">
            1
          </span>
          <span className="flex size-5 items-center justify-center rounded-full bg-warning/15 text-[9px] font-bold text-warning">
            2
          </span>
          {collapsed ? (
            <ChevronDown className="size-4 text-muted-foreground" />
          ) : (
            <ChevronUp className="size-4 text-muted-foreground" />
          )}
        </div>
      </button>
      {!collapsed && (
        <div className="flex flex-col gap-2.5 border-t border-border/30 px-4 pb-4 pt-3">
          {issues.map((issue, i) => (
            <div
              key={i}
              className={cn(
                "rounded-lg border p-3 transition-all",
                issue.severity === "critical" && issue.status === "resolved"
                  ? "border-success/20 bg-success/5"
                  : issue.severity === "warning"
                    ? "border-warning/20 bg-warning/5"
                    : "border-border/30 bg-secondary/20"
              )}
            >
              <div className="flex items-center gap-2">
                {issue.status === "resolved" ? (
                  <CheckCircle2 className="size-3.5 text-success" />
                ) : (
                  <AlertTriangle className="size-3.5 text-warning" />
                )}
                <span className="text-xs font-medium text-foreground">
                  {issue.title}
                </span>
                {issue.status === "resolved" && (
                  <span className="ml-auto rounded-full bg-success/15 px-2 py-0.5 text-[9px] font-semibold text-success">
                    FIXED
                  </span>
                )}
              </div>
              <p className="mt-1.5 text-[11px] leading-relaxed text-muted-foreground">
                {issue.description}
              </p>
            </div>
          ))}
        </div>
      )}
    </GlassCard>
  )
}

function EducationalBreakdown() {
  const [collapsed, setCollapsed] = useState(false)
  const [activeTab, setActiveTab] = useState<"performance" | "security" | "patterns">("performance")

  const tabs = {
    performance: {
      title: "Performance Optimization",
      items: [
        {
          before: "O(n\u00B2) nested loop",
          after: "O(1) HashMap lookup",
          explanation:
            "By building a Map keyed by email, we convert repeated linear scans into constant-time lookups. For 10,000 users, that's ~100M operations reduced to ~10,000.",
        },
        {
          before: "Function recreated every render",
          after: "useCallback memoization",
          explanation:
            "Wrapping login in useCallback prevents child components from unnecessary re-renders when the parent state changes.",
        },
      ],
    },
    security: {
      title: "Security Improvements",
      items: [
        {
          before: 'password === "plaintext"',
          after: "bcrypt.compare(hash)",
          explanation:
            "Bcrypt uses a salt and work factor to make password cracking computationally expensive. Even identical passwords produce different hashes.",
        },
        {
          before: "length > 0 check only",
          after: "Regex-based validation",
          explanation:
            "The new validation enforces minimum 8 characters with uppercase, lowercase, and numeric requirements - matching OWASP guidelines.",
        },
      ],
    },
    patterns: {
      title: "Code Patterns",
      items: [
        {
          before: "Imperative for loops",
          after: 'Declarative for...of + Map',
          explanation:
            "Modern JS patterns favor declarative iteration. for...of is cleaner than indexed loops and Map provides semantically clear key-value storage.",
        },
        {
          before: "Sync function signature",
          after: "Async/await pattern",
          explanation:
            "Making the function async properly handles the bcrypt comparison (which is CPU-intensive) without blocking the main thread.",
        },
      ],
    },
  }

  const current = tabs[activeTab]

  return (
    <GlassCard>
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="flex w-full items-center justify-between p-4"
      >
        <div className="flex items-center gap-2.5">
          <div className="flex size-7 items-center justify-center rounded-lg bg-chart-3/15 shadow-[0_0_12px] shadow-chart-3/10">
            <GraduationCap className="size-4 text-chart-3" />
          </div>
          <div className="text-left">
            <h3 className="text-sm font-semibold text-foreground">
              Educational Breakdown
            </h3>
            <p className="text-[10px] text-muted-foreground">
              3 categories, 6 insights
            </p>
          </div>
        </div>
        {collapsed ? (
          <ChevronDown className="size-4 text-muted-foreground" />
        ) : (
          <ChevronUp className="size-4 text-muted-foreground" />
        )}
      </button>
      {!collapsed && (
        <div className="border-t border-border/30">
          {/* Tab bar */}
          <div className="flex gap-0 border-b border-border/30">
            {(Object.keys(tabs) as (keyof typeof tabs)[]).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={cn(
                  "flex-1 px-3 py-2 text-[11px] font-medium capitalize transition-all",
                  activeTab === tab
                    ? "border-b-2 border-primary text-primary"
                    : "text-muted-foreground hover:text-secondary-foreground"
                )}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="flex flex-col gap-3 p-4">
            <h4 className="text-xs font-semibold text-foreground">
              {current.title}
            </h4>
            {current.items.map((item, i) => (
              <div
                key={i}
                className="rounded-lg border border-border/30 bg-secondary/20 p-3"
              >
                <div className="flex items-center gap-2 text-[11px]">
                  <span className="rounded-md bg-diff-remove px-2 py-0.5 font-mono text-diff-remove-text">
                    {item.before}
                  </span>
                  <ArrowRight className="size-3 text-muted-foreground" />
                  <span className="rounded-md bg-diff-add px-2 py-0.5 font-mono text-diff-add-text">
                    {item.after}
                  </span>
                </div>
                <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">
                  {item.explanation}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </GlassCard>
  )
}

export function AIMentorPanel() {
  return (
    <div className="flex flex-col gap-3">
      <AIDiffSummary />
      <SecurityScan />
      <EducationalBreakdown />
    </div>
  )
}
