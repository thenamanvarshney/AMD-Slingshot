"use client"

import {
  GitBranch,
  Bell,
  Search,
  Settings,
  Sparkles,
  CircleDot,
} from "lucide-react"

export function AppHeader() {
  return (
    <header className="flex h-12 shrink-0 items-center justify-between border-b border-border/50 bg-secondary/20 px-4 backdrop-blur-sm">
      {/* Left section */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="flex size-7 items-center justify-center rounded-lg bg-primary/15 shadow-[0_0_10px] shadow-glow-muted">
            <Sparkles className="size-4 text-primary" />
          </div>
          <span className="text-sm font-bold tracking-tight text-foreground">
            CodeLens
          </span>
          <span className="text-sm font-light text-primary">AI</span>
        </div>

        <div className="h-4 w-px bg-border/50" />

        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <GitBranch className="size-3.5" />
          <span className="font-mono">main</span>
          <span className="text-muted-foreground/40">/</span>
          <span className="font-mono text-primary">feature/auth-refactor</span>
        </div>

        <div className="flex items-center gap-1 rounded-full bg-success/10 px-2 py-0.5">
          <CircleDot className="size-2.5 text-success" />
          <span className="text-[10px] font-medium text-success">
            CI Passing
          </span>
        </div>
      </div>

      {/* Right section */}
      <div className="flex items-center gap-2">
        <button className="flex items-center gap-2 rounded-lg border border-border/50 bg-secondary/40 px-3 py-1.5 text-xs text-muted-foreground transition-all hover:border-primary/30 hover:text-secondary-foreground">
          <Search className="size-3.5" />
          <span>Search files...</span>
          <kbd className="rounded border border-border/50 bg-secondary px-1.5 py-0.5 font-mono text-[9px] text-muted-foreground/60">
            {"/"}</kbd>
        </button>
        <button className="relative rounded-lg p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-secondary-foreground">
          <Bell className="size-4" />
          <span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-primary shadow-[0_0_6px] shadow-glow-muted" />
        </button>
        <button className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-secondary-foreground">
          <Settings className="size-4" />
        </button>
        <div className="ml-1 flex size-7 items-center justify-center rounded-full bg-primary/20 text-xs font-bold text-primary ring-1 ring-primary/30">
          S
        </div>
      </div>
    </header>
  )
}
