"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { Copy, Check, Maximize2, Minimize2, GitCompare } from "lucide-react"

interface DiffLine {
  lineNum: number | null
  content: string
  type: "normal" | "added" | "removed" | "context"
}

const previousCode: DiffLine[] = [
  { lineNum: 1, content: 'import { useState } from "react";', type: "normal" },
  { lineNum: 2, content: "", type: "normal" },
  { lineNum: 3, content: "interface User {", type: "normal" },
  { lineNum: 4, content: "  id: string;", type: "normal" },
  { lineNum: 5, content: "  email: string;", type: "normal" },
  { lineNum: 6, content: "  password: string;", type: "removed" },
  { lineNum: 7, content: "}", type: "normal" },
  { lineNum: 8, content: "", type: "normal" },
  { lineNum: 9, content: "function findUser(users: User[], email: string) {", type: "removed" },
  { lineNum: 10, content: "  // O(n^2) nested loop approach", type: "removed" },
  { lineNum: 11, content: "  for (let i = 0; i < users.length; i++) {", type: "removed" },
  { lineNum: 12, content: "    for (let j = 0; j < users.length; j++) {", type: "removed" },
  { lineNum: 13, content: "      if (users[i].email === email) {", type: "removed" },
  { lineNum: 14, content: "        return users[i];", type: "removed" },
  { lineNum: 15, content: "      }", type: "removed" },
  { lineNum: 16, content: "    }", type: "removed" },
  { lineNum: 17, content: "  }", type: "removed" },
  { lineNum: 18, content: "  return null;", type: "removed" },
  { lineNum: 19, content: "}", type: "removed" },
  { lineNum: 20, content: "", type: "normal" },
  { lineNum: 21, content: "function validatePassword(password: string) {", type: "removed" },
  { lineNum: 22, content: '  if (password.length > 0) return true;', type: "removed" },
  { lineNum: 23, content: "  return false;", type: "removed" },
  { lineNum: 24, content: "}", type: "removed" },
  { lineNum: 25, content: "", type: "normal" },
  { lineNum: 26, content: "export function useAuth() {", type: "normal" },
  { lineNum: 27, content: "  const [user, setUser] = useState<User | null>(null);", type: "normal" },
  { lineNum: 28, content: "", type: "normal" },
  { lineNum: 29, content: "  const login = (email: string, password: string) => {", type: "removed" },
  { lineNum: 30, content: "    // Direct string comparison - INSECURE!", type: "removed" },
  { lineNum: 31, content: "    const users = getUsers();", type: "removed" },
  { lineNum: 32, content: "    const found = findUser(users, email);", type: "removed" },
  { lineNum: 33, content: "    if (found && found.password === password) {", type: "removed" },
  { lineNum: 34, content: "      setUser(found);", type: "removed" },
  { lineNum: 35, content: "    }", type: "removed" },
  { lineNum: 36, content: "  };", type: "normal" },
  { lineNum: 37, content: "", type: "normal" },
  { lineNum: 38, content: "  return { user, login };", type: "normal" },
  { lineNum: 39, content: "}", type: "normal" },
]

const newCode: DiffLine[] = [
  { lineNum: 1, content: 'import { useState, useCallback } from "react";', type: "normal" },
  { lineNum: 2, content: 'import { hash, compare } from "bcryptjs";', type: "added" },
  { lineNum: 3, content: "", type: "normal" },
  { lineNum: 4, content: "interface User {", type: "normal" },
  { lineNum: 5, content: "  id: string;", type: "normal" },
  { lineNum: 6, content: "  email: string;", type: "normal" },
  { lineNum: 7, content: "  passwordHash: string;", type: "added" },
  { lineNum: 8, content: "}", type: "normal" },
  { lineNum: 9, content: "", type: "normal" },
  { lineNum: 10, content: "// O(1) lookup using a HashMap", type: "added" },
  { lineNum: 11, content: "function buildUserIndex(users: User[]) {", type: "added" },
  { lineNum: 12, content: "  const map = new Map<string, User>();", type: "added" },
  { lineNum: 13, content: "  for (const user of users) {", type: "added" },
  { lineNum: 14, content: "    map.set(user.email, user);", type: "added" },
  { lineNum: 15, content: "  }", type: "added" },
  { lineNum: 16, content: "  return map;", type: "added" },
  { lineNum: 17, content: "}", type: "added" },
  { lineNum: 18, content: "", type: "normal" },
  { lineNum: 19, content: "function findUser(index: Map<string, User>, email: string) {", type: "added" },
  { lineNum: 20, content: "  return index.get(email) ?? null;", type: "added" },
  { lineNum: 21, content: "}", type: "added" },
  { lineNum: 22, content: "", type: "normal" },
  { lineNum: 23, content: "function validatePassword(password: string): boolean {", type: "added" },
  { lineNum: 24, content: "  const minLength = 8;", type: "added" },
  { lineNum: 25, content: "  const hasUpper = /[A-Z]/.test(password);", type: "added" },
  { lineNum: 26, content: "  const hasLower = /[a-z]/.test(password);", type: "added" },
  { lineNum: 27, content: "  const hasNumber = /[0-9]/.test(password);", type: "added" },
  { lineNum: 28, content: "  return password.length >= minLength", type: "added" },
  { lineNum: 29, content: "    && hasUpper && hasLower && hasNumber;", type: "added" },
  { lineNum: 30, content: "}", type: "added" },
  { lineNum: 31, content: "", type: "normal" },
  { lineNum: 32, content: "export function useAuth() {", type: "normal" },
  { lineNum: 33, content: "  const [user, setUser] = useState<User | null>(null);", type: "normal" },
  { lineNum: 34, content: "", type: "normal" },
  { lineNum: 35, content: "  const login = useCallback(async (", type: "added" },
  { lineNum: 36, content: "    email: string,", type: "added" },
  { lineNum: 37, content: "    password: string", type: "added" },
  { lineNum: 38, content: "  ) => {", type: "added" },
  { lineNum: 39, content: "    const users = await getUsers();", type: "added" },
  { lineNum: 40, content: "    const index = buildUserIndex(users);", type: "added" },
  { lineNum: 41, content: "    const found = findUser(index, email);", type: "added" },
  { lineNum: 42, content: "    if (found && await compare(password, found.passwordHash)) {", type: "added" },
  { lineNum: 43, content: "      setUser(found);", type: "added" },
  { lineNum: 44, content: "    }", type: "added" },
  { lineNum: 45, content: "  }, []);", type: "added" },
  { lineNum: 46, content: "", type: "normal" },
  { lineNum: 47, content: "  return { user, login };", type: "normal" },
  { lineNum: 48, content: "}", type: "normal" },
]

function CodePanel({
  title,
  lines,
  variant,
}: {
  title: string
  lines: DiffLine[]
  variant: "previous" | "new"
}) {
  const [copied, setCopied] = useState(false)

  const handleCopy = () => {
    const text = lines.map((l) => l.content).join("\n")
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="flex min-w-0 flex-1 flex-col">
      {/* Panel Header */}
      <div className="flex items-center justify-between border-b border-border/50 bg-secondary/30 px-4 py-2">
        <div className="flex items-center gap-2">
          <span
            className={cn(
              "size-2 rounded-full",
              variant === "previous"
                ? "bg-diff-remove-text"
                : "bg-diff-add-text"
            )}
          />
          <span className="text-xs font-medium text-secondary-foreground">
            {title}
          </span>
          <span className="font-mono text-[10px] text-muted-foreground">
            {variant === "previous" ? "useAuth.ts (v2.0.3)" : "useAuth.ts (v2.1.0)"}
          </span>
        </div>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1 rounded-md px-2 py-1 text-xs text-muted-foreground transition-colors hover:bg-secondary hover:text-secondary-foreground"
        >
          {copied ? <Check className="size-3" /> : <Copy className="size-3" />}
          <span>{copied ? "Copied" : "Copy"}</span>
        </button>
      </div>

      {/* Code Lines */}
      <div className="flex-1 overflow-auto font-mono text-[13px] leading-[22px]">
        {lines.map((line, i) => (
          <div
            key={i}
            className={cn(
              "flex",
              line.type === "added" && "bg-diff-add",
              line.type === "removed" && "bg-diff-remove"
            )}
          >
            <span className="flex w-12 shrink-0 select-none items-center justify-end pr-3 text-[11px] text-muted-foreground/40">
              {line.lineNum}
            </span>
            <span className="flex w-5 shrink-0 items-center justify-center text-[11px]">
              {line.type === "added" && (
                <span className="text-diff-add-text">{"+"}</span>
              )}
              {line.type === "removed" && (
                <span className="text-diff-remove-text">{"-"}</span>
              )}
            </span>
            <span
              className={cn(
                "flex-1 whitespace-pre pr-4",
                line.type === "added" && "text-diff-add-text",
                line.type === "removed" && "text-diff-remove-text",
                line.type === "normal" && "text-secondary-foreground/90"
              )}
            >
              {highlightSyntax(line.content)}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

function highlightSyntax(code: string) {
  const keywords =
    /\b(import|export|function|const|let|var|return|if|for|of|new|async|await|from|interface|type|null|true|false|string|boolean|number)\b/g
  const strings = /(["'`])(?:(?=(\\?))\2.)*?\1/g
  const comments = /(\/\/.*$)/gm
  const types = /\b([A-Z][a-zA-Z]*)\b/g

  const parts: { text: string; className: string; index: number }[] = []
  let match: RegExpExecArray | null

  while ((match = comments.exec(code)) !== null) {
    parts.push({
      text: match[0],
      className: "text-muted-foreground/60 italic",
      index: match.index,
    })
  }
  while ((match = strings.exec(code)) !== null) {
    if (!parts.some((p) => match!.index >= p.index && match!.index < p.index + p.text.length)) {
      parts.push({
        text: match[0],
        className: "text-success",
        index: match.index,
      })
    }
  }
  while ((match = keywords.exec(code)) !== null) {
    if (!parts.some((p) => match!.index >= p.index && match!.index < p.index + p.text.length)) {
      parts.push({
        text: match[0],
        className: "text-primary font-medium",
        index: match.index,
      })
    }
  }
  while ((match = types.exec(code)) !== null) {
    if (!parts.some((p) => match!.index >= p.index && match!.index < p.index + p.text.length)) {
      parts.push({
        text: match[0],
        className: "text-warning",
        index: match.index,
      })
    }
  }

  if (parts.length === 0) return code

  parts.sort((a, b) => a.index - b.index)

  const result: (string | JSX.Element)[] = []
  let lastIndex = 0

  parts.forEach((part, i) => {
    if (part.index > lastIndex) {
      result.push(code.slice(lastIndex, part.index))
    }
    result.push(
      <span key={i} className={part.className}>
        {part.text}
      </span>
    )
    lastIndex = part.index + part.text.length
  })

  if (lastIndex < code.length) {
    result.push(code.slice(lastIndex))
  }

  return <>{result}</>
}

export function CodeDiffViewer() {
  const [expanded, setExpanded] = useState(false)

  return (
    <div className="flex h-full flex-col overflow-hidden rounded-xl border border-border/50 bg-code-bg">
      {/* Toolbar */}
      <div className="flex items-center justify-between border-b border-border/50 bg-secondary/20 px-4 py-2">
        <div className="flex items-center gap-3">
          <GitCompare className="size-4 text-primary" />
          <span className="text-sm font-medium text-secondary-foreground">
            Diff Viewer
          </span>
          <div className="flex items-center gap-1 rounded-full bg-primary/10 px-2.5 py-0.5">
            <span className="text-[10px] font-medium text-primary">
              +24 lines
            </span>
          </div>
          <div className="flex items-center gap-1 rounded-full bg-destructive/10 px-2.5 py-0.5">
            <span className="text-[10px] font-medium text-destructive">
              -18 lines
            </span>
          </div>
        </div>
        <button
          onClick={() => setExpanded(!expanded)}
          className="rounded-md p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-secondary-foreground"
        >
          {expanded ? (
            <Minimize2 className="size-3.5" />
          ) : (
            <Maximize2 className="size-3.5" />
          )}
        </button>
      </div>

      {/* Split View */}
      <div className="flex flex-1 overflow-hidden">
        <CodePanel
          title="Previous Code"
          lines={previousCode}
          variant="previous"
        />
        <div className="w-px bg-border/50" />
        <CodePanel title="New Code" lines={newCode} variant="new" />
      </div>

      {/* Status Bar */}
      <div className="flex items-center justify-between border-t border-border/50 bg-secondary/20 px-4 py-1.5">
        <div className="flex items-center gap-4 text-[10px] text-muted-foreground">
          <span>TypeScript React</span>
          <span>UTF-8</span>
          <span>LF</span>
        </div>
        <div className="flex items-center gap-4 text-[10px] text-muted-foreground">
          <span>2 files changed</span>
          <span>48 lines</span>
        </div>
      </div>
    </div>
  )
}
