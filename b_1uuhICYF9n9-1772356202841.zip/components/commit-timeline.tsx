"use client"

import { useState } from "react"
import { GitCommitHorizontal, Tag } from "lucide-react"
import { cn } from "@/lib/utils"

interface Commit {
  id: string
  version: string
  message: string
  author: string
  time: string
  isCurrent?: boolean
  isTag?: boolean
}

const commits: Commit[] = [
  {
    id: "a3f2c1d",
    version: "v2.1.0",
    message: "Refactor auth with hash maps",
    author: "sarah.dev",
    time: "2m ago",
    isCurrent: true,
    isTag: true,
  },
  {
    id: "b7e4f9a",
    version: "v2.0.3",
    message: "Fix security vulnerability in login",
    author: "sarah.dev",
    time: "1h ago",
    isTag: false,
  },
  {
    id: "c5d8e2b",
    version: "v2.0.2",
    message: "Add rate limiting to API",
    author: "alex.eng",
    time: "3h ago",
    isTag: false,
  },
  {
    id: "d1a6c3f",
    version: "v2.0.1",
    message: "Update dependencies",
    author: "bot",
    time: "5h ago",
    isTag: false,
  },
  {
    id: "e9b2d7c",
    version: "v2.0.0",
    message: "Major release: new auth system",
    author: "sarah.dev",
    time: "1d ago",
    isTag: true,
  },
  {
    id: "f4c1a8e",
    version: "v1.9.2",
    message: "Performance improvements",
    author: "alex.eng",
    time: "2d ago",
    isTag: false,
  },
  {
    id: "g6d3b5a",
    version: "v1.9.1",
    message: "Bug fixes and stability",
    author: "sarah.dev",
    time: "3d ago",
    isTag: false,
  },
]

export function CommitTimeline() {
  const [selectedCommit, setSelectedCommit] = useState(commits[0].id)

  return (
    <div className="flex flex-col">
      {commits.map((commit, index) => (
        <button
          key={commit.id}
          onClick={() => setSelectedCommit(commit.id)}
          className={cn(
            "group relative flex items-start gap-3 px-3 py-2.5 text-left transition-all",
            "hover:bg-secondary/50 rounded-md",
            selectedCommit === commit.id && "bg-primary/5"
          )}
        >
          {/* Timeline line */}
          <div className="relative flex flex-col items-center">
            <div
              className={cn(
                "relative z-10 flex size-6 shrink-0 items-center justify-center rounded-full border transition-all",
                commit.isCurrent
                  ? "border-primary bg-primary/20 shadow-[0_0_10px] shadow-glow-muted"
                  : selectedCommit === commit.id
                    ? "border-primary/60 bg-primary/10"
                    : "border-border bg-secondary"
              )}
            >
              {commit.isTag ? (
                <Tag
                  className={cn(
                    "size-3",
                    commit.isCurrent || selectedCommit === commit.id
                      ? "text-primary"
                      : "text-muted-foreground"
                  )}
                />
              ) : (
                <GitCommitHorizontal
                  className={cn(
                    "size-3",
                    selectedCommit === commit.id
                      ? "text-primary"
                      : "text-muted-foreground"
                  )}
                />
              )}
            </div>
            {index < commits.length - 1 && (
              <div className="absolute top-6 h-full w-px bg-border" />
            )}
          </div>

          {/* Content */}
          <div className="flex min-w-0 flex-col gap-0.5 pt-0.5">
            <div className="flex items-center gap-2">
              <span
                className={cn(
                  "font-mono text-xs font-semibold",
                  commit.isCurrent || selectedCommit === commit.id
                    ? "text-primary"
                    : "text-muted-foreground"
                )}
              >
                {commit.version}
              </span>
              <span className="font-mono text-[10px] text-muted-foreground/60">
                {commit.id}
              </span>
            </div>
            <p className="truncate text-xs text-secondary-foreground">
              {commit.message}
            </p>
            <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground/60">
              <span>{commit.author}</span>
              <span>{"·"}</span>
              <span>{commit.time}</span>
            </div>
          </div>
        </button>
      ))}
    </div>
  )
}
