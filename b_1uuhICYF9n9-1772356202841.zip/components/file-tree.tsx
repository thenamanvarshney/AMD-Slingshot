"use client"

import { useState } from "react"
import {
  ChevronRight,
  ChevronDown,
  Folder,
  FolderOpen,
  FileText,
  FileCode,
  FileJson,
  File,
  Settings,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface FileNode {
  name: string
  type: "file" | "folder"
  children?: FileNode[]
  modified?: boolean
  icon?: "code" | "json" | "config" | "text"
}

const fileTree: FileNode[] = [
  {
    name: "src",
    type: "folder",
    children: [
      {
        name: "components",
        type: "folder",
        children: [
          { name: "UserAuth.tsx", type: "file", icon: "code", modified: true },
          { name: "Dashboard.tsx", type: "file", icon: "code" },
          { name: "Sidebar.tsx", type: "file", icon: "code" },
        ],
      },
      {
        name: "utils",
        type: "folder",
        children: [
          { name: "helpers.ts", type: "file", icon: "code", modified: true },
          { name: "constants.ts", type: "file", icon: "code" },
        ],
      },
      {
        name: "hooks",
        type: "folder",
        children: [
          { name: "useAuth.ts", type: "file", icon: "code", modified: true },
        ],
      },
      { name: "App.tsx", type: "file", icon: "code" },
      { name: "index.tsx", type: "file", icon: "code" },
    ],
  },
  {
    name: "config",
    type: "folder",
    children: [
      { name: "tsconfig.json", type: "file", icon: "json" },
      { name: "eslint.config.js", type: "file", icon: "config" },
    ],
  },
  { name: "package.json", type: "file", icon: "json" },
  { name: "README.md", type: "file", icon: "text" },
]

function getFileIcon(icon?: string) {
  switch (icon) {
    case "code":
      return <FileCode className="size-4 text-primary" />
    case "json":
      return <FileJson className="size-4 text-warning" />
    case "config":
      return <Settings className="size-4 text-muted-foreground" />
    case "text":
      return <FileText className="size-4 text-muted-foreground" />
    default:
      return <File className="size-4 text-muted-foreground" />
  }
}

function TreeItem({
  node,
  depth,
  selectedFile,
  onSelect,
}: {
  node: FileNode
  depth: number
  selectedFile: string
  onSelect: (name: string) => void
}) {
  const [expanded, setExpanded] = useState(depth < 2)

  if (node.type === "folder") {
    return (
      <div>
        <button
          onClick={() => setExpanded(!expanded)}
          className={cn(
            "flex w-full items-center gap-1.5 rounded-md px-2 py-1 text-sm transition-colors",
            "hover:bg-secondary/80 text-secondary-foreground"
          )}
          style={{ paddingLeft: `${depth * 12 + 8}px` }}
        >
          {expanded ? (
            <ChevronDown className="size-3.5 text-muted-foreground" />
          ) : (
            <ChevronRight className="size-3.5 text-muted-foreground" />
          )}
          {expanded ? (
            <FolderOpen className="size-4 text-primary" />
          ) : (
            <Folder className="size-4 text-primary/70" />
          )}
          <span className="truncate">{node.name}</span>
        </button>
        {expanded && node.children && (
          <div>
            {node.children.map((child) => (
              <TreeItem
                key={child.name}
                node={child}
                depth={depth + 1}
                selectedFile={selectedFile}
                onSelect={onSelect}
              />
            ))}
          </div>
        )}
      </div>
    )
  }

  return (
    <button
      onClick={() => onSelect(node.name)}
      className={cn(
        "flex w-full items-center gap-1.5 rounded-md px-2 py-1 text-sm transition-all",
        "hover:bg-secondary/80",
        selectedFile === node.name
          ? "bg-primary/10 text-primary"
          : "text-secondary-foreground"
      )}
      style={{ paddingLeft: `${depth * 12 + 24}px` }}
    >
      {getFileIcon(node.icon)}
      <span className="truncate">{node.name}</span>
      {node.modified && (
        <span className="ml-auto size-1.5 shrink-0 rounded-full bg-primary shadow-[0_0_6px] shadow-primary" />
      )}
    </button>
  )
}

export function FileTree() {
  const [selectedFile, setSelectedFile] = useState("UserAuth.tsx")

  return (
    <div className="flex flex-col gap-0.5 p-2">
      {fileTree.map((node) => (
        <TreeItem
          key={node.name}
          node={node}
          depth={0}
          selectedFile={selectedFile}
          onSelect={setSelectedFile}
        />
      ))}
    </div>
  )
}
