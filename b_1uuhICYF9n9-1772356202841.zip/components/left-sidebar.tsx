"use client"

import { useState } from "react"
import { FileTree } from "@/components/file-tree"
import { CommitTimeline } from "@/components/commit-timeline"
import { FolderGit2, History, ChevronDown, ChevronUp } from "lucide-react"
import { cn } from "@/lib/utils"
import { ScrollArea } from "@/components/ui/scroll-area"

export function LeftSidebar() {
  const [fileTreeOpen, setFileTreeOpen] = useState(true)
  const [historyOpen, setHistoryOpen] = useState(true)

  return (
    <aside className="flex h-full w-64 shrink-0 flex-col border-r border-border/50 bg-sidebar">
      {/* File Tree */}
      <div className="flex flex-col">
        <button
          onClick={() => setFileTreeOpen(!fileTreeOpen)}
          className="flex items-center justify-between border-b border-sidebar-border px-3 py-2.5"
        >
          <div className="flex items-center gap-2">
            <FolderGit2 className="size-4 text-sidebar-primary" />
            <span className="text-xs font-semibold uppercase tracking-wider text-sidebar-foreground">
              Explorer
            </span>
          </div>
          {fileTreeOpen ? (
            <ChevronUp className="size-3.5 text-muted-foreground" />
          ) : (
            <ChevronDown className="size-3.5 text-muted-foreground" />
          )}
        </button>
        {fileTreeOpen && (
          <ScrollArea className="max-h-[40vh]">
            <FileTree />
          </ScrollArea>
        )}
      </div>

      {/* Commit History */}
      <div className="flex flex-1 flex-col overflow-hidden border-t border-sidebar-border">
        <button
          onClick={() => setHistoryOpen(!historyOpen)}
          className="flex items-center justify-between px-3 py-2.5"
        >
          <div className="flex items-center gap-2">
            <History className="size-4 text-sidebar-primary" />
            <span className="text-xs font-semibold uppercase tracking-wider text-sidebar-foreground">
              Commit History
            </span>
          </div>
          {historyOpen ? (
            <ChevronUp className="size-3.5 text-muted-foreground" />
          ) : (
            <ChevronDown className="size-3.5 text-muted-foreground" />
          )}
        </button>
        {historyOpen && (
          <ScrollArea className="flex-1">
            <CommitTimeline />
          </ScrollArea>
        )}
      </div>

      {/* Status Bar */}
      <div
        className={cn(
          "flex items-center gap-2 border-t border-sidebar-border px-3 py-2",
          "bg-sidebar"
        )}
      >
        <span className="size-1.5 rounded-full bg-success shadow-[0_0_6px] shadow-success/40" />
        <span className="text-[10px] text-muted-foreground">
          Connected to origin
        </span>
      </div>
    </aside>
  )
}
