"use client"

import { AIMentorPanel } from "@/components/ai-mentor-panel"
import { Bot, Sparkles } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"

export function RightPanel() {
  return (
    <aside className="flex h-full w-80 shrink-0 flex-col border-l border-border/50 bg-sidebar">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-sidebar-border px-4 py-2.5">
        <div className="flex items-center gap-2">
          <Bot className="size-4 text-primary" />
          <span className="text-xs font-semibold uppercase tracking-wider text-sidebar-foreground">
            AI Mentor
          </span>
        </div>
        <div className="flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5">
          <Sparkles className="size-2.5 text-primary" />
          <span className="text-[9px] font-medium text-primary">
            Analyzing...
          </span>
        </div>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        <div className="p-3">
          <AIMentorPanel />
        </div>
      </ScrollArea>

      {/* AI status footer */}
      <div className="flex items-center justify-between border-t border-sidebar-border px-4 py-2">
        <div className="flex items-center gap-2">
          <span className="relative flex size-2">
            <span className="absolute inline-flex size-full animate-ping rounded-full bg-primary/60" />
            <span className="relative inline-flex size-2 rounded-full bg-primary" />
          </span>
          <span className="text-[10px] text-muted-foreground">
            AI Engine Active
          </span>
        </div>
        <span className="text-[10px] text-muted-foreground/50">
          GPT-4o
        </span>
      </div>
    </aside>
  )
}
